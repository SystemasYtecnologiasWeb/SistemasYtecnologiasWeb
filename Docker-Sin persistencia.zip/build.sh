#!/bin/bash
docker build -t sytw/nodejs-server .
docker run -it --name sytw -p 80:80 -d sytw/nodejs-server 
